package com.duma.devices;

import com.duma.core.config.ModuleProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableAsync;

// Core is outside this package's default component scan.
@SpringBootApplication(scanBasePackages = {"com.duma.devices", "com.duma.core"})
@EnableAsync
@EnableConfigurationProperties(ModuleProperties.class)
public class DevicesApplication {
  public static void main(String[] args) {
    SpringApplication.run(DevicesApplication.class, args);
  }
}
