package com.duma.devices.security;

import com.duma.core.config.ModuleProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class ModuleSecurityConfig {
  @Bean
  SecurityFilterChain securityFilterChain(HttpSecurity http, ModuleProperties p) throws Exception {
    http.csrf(c -> c.disable())
        .cors(Customizer.withDefaults())
        .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
    if (p.getSecurity().isStandaloneMode())
      http.authorizeHttpRequests(a -> a.anyRequest().permitAll());
    else
      http.authorizeHttpRequests(
              a ->
                  a.requestMatchers("/api/module/manifest", "/actuator/health")
                      .permitAll()
                      .requestMatchers("/api/**")
                      .authenticated()
                      .anyRequest()
                      .permitAll())
          .oauth2ResourceServer(r -> r.jwt(Customizer.withDefaults()));
    return http.build();
  }
}
