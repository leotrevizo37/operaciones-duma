import { describe, expect, it } from 'vitest'
import { batteryStates } from './battery'
import type { SensorTimeline } from './types'

const row = (timeSpan: string, batteryLevel: number | null, overrides: Partial<SensorTimeline> = {}): SensorTimeline => ({ sensorId: 'sensor-1', timeSpan, localTimeSpan: timeSpan, readingsCount: 6, late: false, disconnected: false, lastReadingAt: timeSpan, connectionLostAt: null, minutesWithoutReadings: 0, devEui: '24e124126e210719', dataCoveragePercentage: 100, receivedUplinkCount: 6, expectedUplinkCount: 6, chirpStackReceiptCoveragePercentage: 100, averageRssi: -86, averageSnr: 5.4, linkErrorCount: 0, gatewayReceivedPacketCount: 240, gatewayTransmittedPacketCount: 0, gatewayTxOkCount: 0, gatewayTxErrorCount: 0, batteryLevel, externalPowerSource: false, batteryLevelSource: batteryLevel == null ? null : 'DEVICE_METRICS', batteryObservedAt: batteryLevel == null ? null : timeSpan, communicationStatus: 'OK', ...overrides })

describe('battery layer inference', () => {
  it('uses a nearby positive report instead of treating periodic zero as depleted', () => {
    const states = batteryStates([row('2026-09-22T10:00:00Z', 0), row('2026-09-22T12:00:00Z', 82)])
    expect(states.get('|sensor-1|2026-09-22T10:00:00Z')).toMatchObject({ kind: 'level', level: 82, inferred: true })
  })

  it('does not infer a level while sensor communication is lost', () => {
    const states = batteryStates([row('2026-09-22T10:00:00Z', 75), row('2026-09-22T11:00:00Z', null, { disconnected: true, communicationStatus: 'DEVICE_NOT_COMMUNICATING' })])
    expect(states.get('|sensor-1|2026-09-22T11:00:00Z')).toMatchObject({ kind: 'unknown', level: null })
  })

  it('marks externally powered sensors as not applicable', () => {
    const states = batteryStates([row('2026-09-22T10:00:00Z', null, { externalPowerSource: true })])
    expect(states.get('|sensor-1|2026-09-22T10:00:00Z')).toMatchObject({ kind: 'not_applicable', level: null })
  })

  it('keeps missing daily battery evidence unknown', () => {
    const states = batteryStates([1, 2, 3].map((day) => row(`2026-09-0${day}T00:00:00Z`, null, { externalPowerSource: null, batteryLevelSource: null, batteryObservedAt: null })))
    expect([...states.values()].every((state) => state.kind === 'unknown')).toBe(true)
  })
})
