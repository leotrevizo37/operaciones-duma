import type { SensorTimeline } from './types'

export type BatteryState = { kind: 'level' | 'not_applicable' | 'unknown'; level: number | null; inferred: boolean; source: string | null; observedAt: string | null; reason: string }

const clamp = (value: number) => Math.max(0, Math.min(100, value))
const communicationIsReliable = (row: SensorTimeline) => !row.disconnected && row.communicationStatus !== 'GATEWAY_PROBLEM' && row.communicationStatus !== 'DEVICE_NOT_COMMUNICATING'

export const batteryStates = (rows: Array<SensorTimeline & { tenantId?: string }>) => {
  const states = new Map<string, BatteryState>(); const groups = new Map<string, Array<SensorTimeline & { tenantId?: string }>>()
  rows.forEach((row) => { const key = `${row.tenantId ?? ''}|${row.sensorId}`; groups.set(key, [...(groups.get(key) ?? []), row]) })
  groups.forEach((group, sensorKey) => {
    const ordered = [...group].sort((left, right) => new Date(left.timeSpan).getTime() - new Date(right.timeSpan).getTime())
    const hasBatteryEvidence = ordered.some((row) => row.batteryLevel != null || row.externalPowerSource === false)
    const notBatteryPowered = !hasBatteryEvidence && ordered.some((row) => row.externalPowerSource === true)
    const observations = ordered.filter((row) => communicationIsReliable(row) && (row.batteryLevel ?? 0) > 0)
    ordered.forEach((row) => {
      const key = `${sensorKey}|${row.timeSpan}`
      if (notBatteryPowered) { states.set(key, { kind: 'not_applicable', level: null, inferred: false, source: null, observedAt: null, reason: 'Sensor sin batería o con alimentación externa' }); return }
      if (communicationIsReliable(row) && (row.batteryLevel ?? 0) > 0) { states.set(key, { kind: 'level', level: clamp(row.batteryLevel!), inferred: false, source: row.batteryLevelSource, observedAt: row.batteryObservedAt, reason: 'Nivel reportado por el sensor' }); return }
      if (!communicationIsReliable(row)) { states.set(key, { kind: 'unknown', level: null, inferred: false, source: row.batteryLevelSource, observedAt: row.batteryObservedAt, reason: row.communicationStatus === 'GATEWAY_PROBLEM' ? 'Sin inferencia por problema del gateway' : 'Sin inferencia durante la pérdida de comunicación' }); return }
      const instant = new Date(row.timeSpan).getTime(); const nearby = observations.map((candidate) => ({ candidate, distance: Math.abs(new Date(candidate.timeSpan).getTime() - instant) })).filter(({ distance }) => distance <= 4 * 3600000).sort((left, right) => left.distance - right.distance)[0]?.candidate
      if (nearby) states.set(key, { kind: 'level', level: clamp(nearby.batteryLevel!), inferred: true, source: nearby.batteryLevelSource, observedAt: nearby.batteryObservedAt, reason: 'Último nivel confiable dentro del ciclo de reporte' })
      else states.set(key, { kind: 'unknown', level: null, inferred: false, source: row.batteryLevelSource, observedAt: row.batteryObservedAt, reason: row.batteryLevel === 0 ? 'El valor 0 no confirma batería agotada' : 'Sin reporte de batería confiable' })
    })
  })
  return states
}
