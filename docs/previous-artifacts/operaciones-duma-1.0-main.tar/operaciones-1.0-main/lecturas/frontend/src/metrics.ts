import type { SensorTimeline, TenantResult } from './types'
export function continuity(tenants: TenantResult[], previous = false) { const summaries = tenants.map((tenant) => previous ? tenant.previous : tenant.current); const observed = summaries.reduce((sum, item) => sum + item.sensorsObserved, 0); const healthy = summaries.reduce((sum, item) => sum + item.healthySensors, 0); return observed ? healthy / observed * 100 : null }
export function communication(tenants: TenantResult[]) { const sensors = tenants.flatMap((tenant) => tenant.sensors ?? []); const observed = sensors.reduce((sum, sensor) => sum + sensor.observedIntervals, 0); const lost = sensors.reduce((sum, sensor) => sum + sensor.lostIntervals, 0); return observed ? (observed - lost) / observed * 100 : null }
export function delta(current: number | null, previous: number | null) { return current == null || previous == null ? null : current - previous }
export function statusLabel(status: TenantResult['coverageStatus']) { return { AVAILABLE: 'Disponible', NO_DATA: 'Sin datos', NOT_SUPPORTED: 'Sin cobertura', UNAVAILABLE: 'No disponible' }[status] }

export function radioSummary(row: SensorTimeline) {
  const hours = (row.diagnostics ?? []).filter((item) => item.source === 'observability.factChirpStackDeviceGatewayMetrics').flatMap((item) => item.hours)
  const profiles = hours.flatMap((hour) => hour.radioReceptionStats ?? [])
  let rssiSum = 0; let rssiCount = 0; let snrSum = 0; let snrCount = 0; let scoreSum = 0; let classifiedCount = 0
  profiles.forEach((profile) => {
    if (profile.rssiSum != null && Number.isFinite(Number(profile.rssiSum)) && Number.isSafeInteger(profile.rssiCount) && profile.rssiCount > 0) { rssiSum += Number(profile.rssiSum); rssiCount += profile.rssiCount }
    if (profile.snrSum == null || !Number.isFinite(Number(profile.snrSum)) || !Number.isSafeInteger(profile.snrCount) || !(profile.snrCount > 0)) return
    snrSum += Number(profile.snrSum); snrCount += profile.snrCount
    const sf = profile.spreadingFactor
    if (sf == null || !Number.isInteger(sf) || sf < 7 || sf > 12 || ![125000, 250000, 500000].includes(profile.bandwidthHz ?? 0) || profile.frequencyHz == null || profile.frequencyHz < 100000000 || profile.frequencyHz >= 1000000000) return
    const margin = Number(profile.snrSum) / profile.snrCount - (-7.5 - 2.5 * (sf - 7))
    scoreSum += Math.max(0, Math.min(100, (margin + 5) * 100 / 15)) * profile.snrCount; classifiedCount += profile.snrCount
  })
  const receptions = hours.reduce((sum, hour) => sum + (hour.gatewayReceptionCount ?? 0), 0)
  const score = classifiedCount ? scoreSum / classifiedCount : null
  return { profiles, receptions, rssiCount, snrCount, classifiedCount, averageRssi: rssiCount ? rssiSum / rssiCount : null, averageSnr: snrCount ? snrSum / snrCount : null, score, quality: score == null ? 'sin perfil evaluable' : score < 100 / 3 ? 'crítica' : score < 220 / 3 ? 'degradada' : 'buena' }
}

export function diagnosticCounts(row: SensorTimeline, source: string, field: 'linkErrorCounts' | 'eventLogCounts' | 'txPacketStatusCounts') {
  const hours = (row.diagnostics ?? []).filter((item) => item.source === source).flatMap((item) => item.hours)
  const counts: Record<string, number> = Object.create(null) as Record<string, number>
  let availableHours = 0
  const seen = new Set<string>()
  hours.forEach((hour) => { const key = hour.timeSpan + '|' + (hour.gatewayId ?? hour.devEui); if (seen.has(key)) return; seen.add(key); const values = hour[field]; if (values == null) return; availableHours++; Object.entries(values).forEach(([code, count]) => { if (Number.isFinite(count) && count > 0) counts[code] = (counts[code] ?? 0) + count }) })
  return { counts, availableHours, observedHours: hours.length }
}
