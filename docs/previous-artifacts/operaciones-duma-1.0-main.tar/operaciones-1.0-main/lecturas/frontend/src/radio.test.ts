import { describe, expect, it } from 'vitest'
import { diagnosticCounts, radioSummary } from './metrics'
import type { RadioReception, SensorTimeline } from './types'

const profile = (sf: number, snr: number, count = 1): RadioReception => ({ regionConfigId: 'us915_0', adr: true, dr: 0, spreadingFactor: sf, bandwidthHz: 125000, frequencyHz: 915200000, channel: 0, rfChain: 0, receptionCount: count, rssiCount: count, rssiSum: String(-110 * count), rssiMin: '-110', rssiMax: '-110', snrCount: count, snrSum: String(snr * count), snrMin: String(snr), snrMax: String(snr) })
const row = (profiles: RadioReception[], receptions = 1) => ({ diagnostics: [{ sensorId: 's', localPeriodStart: '2026-10-07T00:00:00', source: 'observability.factChirpStackDeviceGatewayMetrics', hours: [{ timeSpan: '2026-10-07T06:00:00Z', devEui: '0000000000000001', gatewayId: '0000000000000002', gatewayReceptionCount: receptions, radioReceptionStats: profiles }] }] }) as SensorTimeline

describe('radio evidence', () => {
  it('distinguishes identical signal at different SF without guessing SF5 thresholds', () => {
    expect(radioSummary(row([profile(7, -15)])).score).toBe(0)
    expect(radioSummary(row([profile(10, -15)])).score).toBeCloseTo(100 / 3)
    expect(radioSummary(row([profile(12, -15)])).score).toBeCloseTo(200 / 3)
    expect(radioSummary(row([profile(5, -15)])).score).toBeNull()
  })
  it('weights each magnitude by its own valid samples', () => {
    const result = radioSummary(row([profile(7, 0, 1), { ...profile(12, -15, 3), rssiCount: 0, rssiSum: null }], 10))
    expect(result.averageSnr).toBe(-11.25)
    expect(result.averageRssi).toBe(-110)
    expect(result.classifiedCount).toBe(4)
    expect(result.receptions).toBe(10)
  })
  it('does not classify missing detail, unsupported bands, or invalid decimal strings', () => {
    expect(radioSummary(row([])).score).toBeNull()
    expect(radioSummary(row([{ ...profile(7, 0), frequencyHz: 2400000000 }])).score).toBeNull()
    expect(radioSummary(row([{ ...profile(7, 0), snrSum: 'invalid' }])).score).toBeNull()
  })
  it('preserves missing and empty breakdowns and dynamic codes safely', () => {
    const source = 'observability.factChirpStackDeviceEventMetrics'
    const item = { diagnostics: [{ source, hours: [{ timeSpan: 'a', devEui: 'd', eventLogCounts: null }, { timeSpan: 'b', devEui: 'd', eventLogCounts: {} }, { timeSpan: 'c', devEui: 'd', eventLogCounts: JSON.parse('{"__proto__":2,"INFO":3}') }] }] } as SensorTimeline
    const result = diagnosticCounts(item, source, 'eventLogCounts')
    expect(result.availableHours).toBe(2)
    expect(result.counts.INFO).toBe(3)
    expect(result.counts.__proto__).toBe(2)
  })
})
