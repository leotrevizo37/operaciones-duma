import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'
import type { HostContext } from './types'

const to = new Date().toISOString().slice(0, 10)
const from = new Date()
from.setUTCDate(from.getUTCDate() - 30)
const context: HostContext = {
  protocolVersion: '1.0',
  moduleId: 'smartaudits',
  locale: 'es-MX',
  timezone: 'America/Mexico_City',
  tenantIds: [],
  period: { from: from.toISOString().slice(0, 10), to },
  freshness: [],
  identity: {
    subject: 'standalone-read',
    displayName: 'Modo standalone',
    roles: [],
    permissions: [],
    tenantScope: [],
  },
  apiBaseUrl: '',
  auth: { getAccessToken: async () => '' },
  navigate: () => undefined,
}

createRoot(document.getElementById('root')!).render(<StrictMode><App context={context} /></StrictMode>)
